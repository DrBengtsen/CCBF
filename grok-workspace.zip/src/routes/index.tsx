import { createFileRoute } from "@tanstack/react-router";
import { FestivalApp } from "@/components/festival-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <FestivalApp />;
}
