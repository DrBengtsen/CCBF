export function HopMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={className}
      aria-hidden="true"
      fill="none"
    >
      <path
        d="M16 3c1.4 3.2 3.8 5.4 7 6.6-2.1 1.6-3.6 3.8-4.4 6.4 1.8-.6 3.6-.8 5.4-.4-1.6 3.4-4.4 5.8-8 6.8 3.6 1 6.4 3.4 8 6.8-1.8.4-3.6.2-5.4-.4.8 2.6 2.3 4.8 4.4 6.4-3.2 1.2-5.6 3.4-7 6.6-1.4-3.2-3.8-5.4-7-6.6 2.1-1.6 3.6-3.8 4.4-6.4-1.8.6-3.6.8-5.4.4 1.6-3.4 4.4-5.8 8-6.8-3.6-1-6.4-3.4-8-6.8 1.8-.4 3.6-.2 5.4.4C9.2 13.4 7.7 11.2 5.6 9.6 8.8 8.4 11.2 6.2 12.6 3h3.4Z"
        transform="scale(.72) translate(6.2 2.2)"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      <path
        d="M16 8v16"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
      />
    </svg>
  );
}
