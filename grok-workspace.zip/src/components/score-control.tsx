import { cn } from "@/lib/utils";

const STEPS = [0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5];

type Props = {
  value: number | null;
  onChange: (value: number | null) => void;
  compact?: boolean;
};

export function ScoreControl({ value, onChange, compact }: Props) {
  return (
    <div className="flex flex-col gap-2">
      {!compact ? (
        <div className="flex items-baseline justify-between">
          <span className="text-xs font-medium uppercase tracking-wider text-subtle">
            Din score
          </span>
          <span className="font-mono text-sm tabular-nums text-rating">
            {value == null ? "–" : value.toFixed(2)}
          </span>
        </div>
      ) : null}
      <div className={cn("flex flex-wrap gap-1", compact && "justify-end")}>
        {STEPS.map((step) => {
          const active = value != null && value >= step;
          const exact = value === step;
          return (
            <button
              key={step}
              type="button"
              aria-label={`Sæt score ${step}`}
              onClick={() => onChange(value === step ? null : step)}
              className={cn(
                "min-w-8 rounded-sm px-1.5 font-mono text-xs tabular-nums transition-colors duration-150",
                compact ? "h-8" : "h-9",
                exact
                  ? "bg-rating text-accent-fg"
                  : active
                    ? "bg-rating/25 text-rating"
                    : "bg-elevated text-subtle hover:text-fg",
              )}
            >
              {step % 1 === 0 ? step.toFixed(0) : step.toFixed(1)}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export function ScoreBadge({ score }: { score: number | null }) {
  if (score == null) {
    return <span className="font-mono text-xs tabular-nums text-subtle">–</span>;
  }
  return (
    <span className="font-mono text-sm font-semibold tabular-nums text-rating">
      {score.toFixed(2)}
    </span>
  );
}
