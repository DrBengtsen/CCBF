import { useMemo, useState, type ReactNode } from "react";
import {
  ArrowDown,
  ArrowUp,
  Bookmark,
  Check,
  ExternalLink,
  Plus,
  Search,
  X,
} from "lucide-react";
import { Drawer } from "vaul";
import {
  BEERS,
  BREWERIES,
  FAMILY_LABEL,
  type Beer,
  type StyleFamily,
} from "@/data/beers";
import { useCrew } from "@/lib/store";
import { cn, formatAbv, formatRating, initials } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { HopMark } from "@/components/hop-mark";
import { ScoreBadge, ScoreControl } from "@/components/score-control";

type SortKey = "untappd" | "name" | "brewery" | "style" | "abv" | "mine" | "drunk";
type DrunkFilter = "all" | "mine" | "todo" | "want" | "friends";

const FAMILIES: StyleFamily[] = [
  "ipa",
  "stout",
  "sour",
  "lager",
  "pale",
  "wheat",
  "mead",
  "other",
];

export function FestivalApp() {
  const members = useCrew((s) => s.members);
  const activeId = useCrew((s) => s.activeId);
  const setActive = useCrew((s) => s.setActive);
  const rename = useCrew((s) => s.rename);
  const addFriend = useCrew((s) => s.addFriend);
  const removeMember = useCrew((s) => s.removeMember);
  const checkins = useCrew((s) => s.checkins);
  const checkinFor = useCrew((s) => s.checkinFor);
  const setDrunk = useCrew((s) => s.setDrunk);
  const setScore = useCrew((s) => s.setScore);
  const setWant = useCrew((s) => s.setWant);

  const active = members.find((m) => m.id === activeId) ?? members[0];
  const [query, setQuery] = useState("");
  const [family, setFamily] = useState<StyleFamily | "all">("all");
  const [brewery, setBrewery] = useState("all");
  const [drunkFilter, setDrunkFilter] = useState<DrunkFilter>("all");
  const [sortKey, setSortKey] = useState<SortKey>("untappd");
  const [sortDir, setSortDir] = useState<"desc" | "asc">("desc");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [friendName, setFriendName] = useState("");
  const [crewOpen, setCrewOpen] = useState(false);

  const selected = BEERS.find((b) => b.id === selectedId) ?? null;

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = BEERS.filter((beer) => {
      if (family !== "all" && beer.family !== family) return false;
      if (brewery !== "all" && beer.brewery !== brewery) return false;
      const mine = checkinFor(activeId, beer.id);
      const friendsDrank = members.some(
        (m) => m.id !== activeId && checkinFor(m.id, beer.id).drunk,
      );
      if (drunkFilter === "mine" && !mine.drunk) return false;
      if (drunkFilter === "todo" && mine.drunk) return false;
      if (drunkFilter === "want" && !mine.want) return false;
      if (drunkFilter === "friends" && !friendsDrank) return false;
      if (!q) return true;
      return (
        beer.name.toLowerCase().includes(q) ||
        beer.brewery.toLowerCase().includes(q) ||
        beer.style.toLowerCase().includes(q) ||
        beer.country.toLowerCase().includes(q)
      );
    });

    const dir = sortDir === "asc" ? 1 : -1;
    list.sort((a, b) => {
      const mineA = checkinFor(activeId, a.id);
      const mineB = checkinFor(activeId, b.id);
      switch (sortKey) {
        case "name":
          return dir * a.name.localeCompare(b.name, "da");
        case "brewery":
          return dir * a.brewery.localeCompare(b.brewery, "da");
        case "style":
          return dir * a.style.localeCompare(b.style, "da");
        case "abv":
          return dir * ((a.abv ?? -1) - (b.abv ?? -1));
        case "mine":
          return dir * ((mineA.score ?? -1) - (mineB.score ?? -1));
        case "drunk":
          return dir * (Number(mineA.drunk) - Number(mineB.drunk));
        default: {
          const ra = a.untappdRating ?? -1;
          const rb = b.untappdRating ?? -1;
          if (ra === rb) return a.name.localeCompare(b.name, "da");
          return dir * (ra - rb);
        }
      }
    });
    return list;
  }, [query, family, brewery, drunkFilter, sortKey, sortDir, activeId, checkins, members, checkinFor]);

  const tasted = BEERS.filter((beer) => checkinFor(activeId, beer.id).drunk).length;
  const scores = BEERS.map((beer) => checkinFor(activeId, beer.id).score).filter(
    (s): s is number => s != null,
  );
  const avg = scores.length
    ? scores.reduce((a, n) => a + n, 0) / scores.length
    : null;

  function toggleSort(key: SortKey) {
    if (sortKey === key) setSortDir((d) => (d === "desc" ? "asc" : "desc"));
    else {
      setSortKey(key);
      setSortDir(key === "name" || key === "brewery" || key === "style" ? "asc" : "desc");
    }
  }

  function submitFriend() {
    if (!friendName.trim()) return;
    addFriend(friendName.trim());
    setFriendName("");
  }

  return (
    <div className="min-h-dvh">
      <header className="border-b border-border/80 bg-bg/80 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl flex-col gap-5 px-4 py-5 sm:px-6 sm:py-7">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="mt-0.5 flex size-11 items-center justify-center rounded-lg border border-border bg-elevated text-accent">
                <HopMark className="size-6" />
              </div>
              <div>
                <p className="font-display text-xs font-medium uppercase tracking-widest text-accent">
                  Den Grå Hal · 19. sep 2026
                </p>
                <h1 className="font-display text-3xl font-medium uppercase leading-none tracking-tight text-fg sm:text-4xl">
                  CCBF 2026
                </h1>
                <p className="mt-1.5 max-w-xl text-sm text-muted">
                  {BEERS.length} øl · 17–22 · unlimited pours. Sorter, kryds af,
                  giv score som på Untappd, og se hvad holdet har smagt.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setCrewOpen((o) => !o)}
              className="flex h-11 shrink-0 items-center gap-2 rounded-md border border-border bg-elevated px-3 text-sm text-fg"
            >
              <span className="flex size-7 items-center justify-center rounded-full bg-accent font-display text-xs text-accent-fg">
                {active.name ? initials(active.name) : "DU"}
              </span>
              <span className="hidden max-w-28 truncate sm:inline">
                {active.name || "Dit navn"}
              </span>
            </button>
          </div>

          {crewOpen ? (
            <CrewPanel
              members={members}
              activeId={activeId}
              friendName={friendName}
              onFriendName={setFriendName}
              onSubmitFriend={submitFriend}
              onActive={setActive}
              onRename={rename}
              onRemove={removeMember}
            />
          ) : null}

          <div className="grid grid-cols-3 gap-2 sm:max-w-md">
            <Stat label="Smagt" value={`${tasted}/${BEERS.length}`} />
            <Stat label="Din snit" value={avg == null ? "–" : avg.toFixed(2)} />
            <Stat label="På listen" value={String(rows.length)} />
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-5 sm:px-6 sm:py-6">
        <div className="flex flex-col gap-3">
          <label className="relative block">
            <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-subtle" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Søg øl, bryggeri, stil…"
              className="pl-10"
            />
          </label>

          <div className="flex gap-2 overflow-x-auto pb-1">
            <Chip active={family === "all"} onClick={() => setFamily("all")}>
              Alle stile
            </Chip>
            {FAMILIES.map((f) => (
              <Chip key={f} active={family === f} onClick={() => setFamily(f)}>
                {FAMILY_LABEL[f]}
              </Chip>
            ))}
          </div>

          <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
            <select
              value={brewery}
              onChange={(e) => setBrewery(e.target.value)}
              className="h-11 rounded-md border border-border bg-elevated px-3 text-sm text-fg focus:border-accent/60 focus:outline-none focus:ring-2 focus:ring-accent/30 sm:max-w-xs"
            >
              <option value="all">Alle bryggerier</option>
              {BREWERIES.map((name) => (
                <option key={name} value={name}>
                  {name}
                </option>
              ))}
            </select>
            <div className="flex gap-2 overflow-x-auto">
              {(
                [
                  ["all", "Alle øl"],
                  ["todo", "Ikke smagt"],
                  ["mine", "Mine"],
                  ["want", "Skal smages"],
                  ["friends", "Venner har smagt"],
                ] as const
              ).map(([key, label]) => (
                <Chip
                  key={key}
                  active={drunkFilter === key}
                  onClick={() => setDrunkFilter(key)}
                >
                  {label}
                </Chip>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-4 overflow-hidden rounded-xl border border-border bg-surface">
          <div className="hidden md:block">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-border bg-elevated/70 text-xs uppercase tracking-wider text-subtle">
                <tr>
                  <Th className="w-12" />
                  <SortTh k="name" current={sortKey} dir={sortDir} onClick={toggleSort}>
                    Øl
                  </SortTh>
                  <SortTh k="brewery" current={sortKey} dir={sortDir} onClick={toggleSort}>
                    Bryggeri
                  </SortTh>
                  <SortTh k="style" current={sortKey} dir={sortDir} onClick={toggleSort}>
                    Stil
                  </SortTh>
                  <SortTh k="abv" current={sortKey} dir={sortDir} onClick={toggleSort}>
                    ABV
                  </SortTh>
                  <SortTh k="untappd" current={sortKey} dir={sortDir} onClick={toggleSort}>
                    Untappd
                  </SortTh>
                  <SortTh k="mine" current={sortKey} dir={sortDir} onClick={toggleSort}>
                    Min
                  </SortTh>
                  <th className="px-3 py-3 font-medium">Hold</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((beer) => {
                  const mine = checkinFor(activeId, beer.id);
                  return (
                    <tr
                      key={beer.id}
                      onClick={() => setSelectedId(beer.id)}
                      className="cursor-pointer border-b border-border/70 last:border-0 hover:bg-elevated/50"
                    >
                      <td className="px-3 py-2.5">
                        <DrunkToggle
                          drunk={mine.drunk}
                          onToggle={() => setDrunk(beer.id, !mine.drunk)}
                        />
                      </td>
                      <td className="px-3 py-2.5">
                        <div className="flex items-center gap-2">
                          {mine.want ? (
                            <Bookmark className="size-3.5 fill-rating text-rating" />
                          ) : null}
                          <span className="font-medium text-fg">{beer.name}</span>
                        </div>
                      </td>
                      <td className="px-3 py-2.5 text-muted">
                        {beer.brewery}
                        <span className="ml-1 text-subtle">{beer.countryCode}</span>
                      </td>
                      <td className="px-3 py-2.5 text-muted">{beer.style}</td>
                      <td className="px-3 py-2.5 font-mono tabular-nums text-muted">
                        {formatAbv(beer.abv)}
                      </td>
                      <td className="px-3 py-2.5">
                        <UntappdCell beer={beer} />
                      </td>
                      <td className="px-3 py-2.5">
                        <ScoreBadge score={mine.score} />
                      </td>
                      <td className="px-3 py-2.5">
                        <FriendPills
                          beerId={beer.id}
                          members={members}
                          activeId={activeId}
                          checkinFor={checkinFor}
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <ul className="divide-y divide-border md:hidden">
            {rows.map((beer) => {
              const mine = checkinFor(activeId, beer.id);
              return (
                <li key={beer.id}>
                  <div className="flex w-full items-start gap-3 px-3 py-3.5">
                    <DrunkToggle
                      drunk={mine.drunk}
                      onToggle={() => setDrunk(beer.id, !mine.drunk)}
                    />
                    <button
                      type="button"
                      onClick={() => setSelectedId(beer.id)}
                      className="min-w-0 flex-1 text-left"
                    >
                      <span className="flex items-center gap-1.5">
                        {mine.want ? (
                          <Bookmark className="size-3.5 fill-rating text-rating" />
                        ) : null}
                        <span className="truncate font-medium text-fg">{beer.name}</span>
                      </span>
                      <span className="mt-0.5 block truncate text-xs text-muted">
                        {beer.brewery} · {beer.style} · {formatAbv(beer.abv)}
                      </span>
                      <span className="mt-2 flex items-center gap-3">
                        <UntappdCell beer={beer} />
                        <span className="text-xs text-subtle">Min</span>
                        <ScoreBadge score={mine.score} />
                        <FriendPills
                          beerId={beer.id}
                          members={members}
                          activeId={activeId}
                          checkinFor={checkinFor}
                        />
                      </span>
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>

          {rows.length === 0 ? (
            <p className="px-4 py-12 text-center text-sm text-muted">
              Ingen øl matcher filtrene.
            </p>
          ) : null}
        </div>
      </main>

      <Drawer.Root
        open={selected != null}
        onOpenChange={(open) => {
          if (!open) setSelectedId(null);
        }}
      >
        <Drawer.Portal>
          <Drawer.Overlay className="fixed inset-0 z-40 bg-bg/70" />
          <Drawer.Content className="fixed inset-x-0 bottom-0 z-50 mx-auto flex max-h-[90vh] max-w-lg flex-col rounded-t-xl border border-border bg-surface outline-none">
            <div className="mx-auto mt-3 h-1 w-10 rounded-full bg-border" />
            {selected ? (
              <BeerDetail
                beer={selected}
                mine={checkinFor(activeId, selected.id)}
                members={members}
                activeId={activeId}
                checkinFor={checkinFor}
                onDrunk={(v) => setDrunk(selected.id, v)}
                onScore={(v) => setScore(selected.id, v)}
                onWant={(v) => setWant(selected.id, v)}
                onClose={() => setSelectedId(null)}
              />
            ) : null}
          </Drawer.Content>
        </Drawer.Portal>
      </Drawer.Root>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-border bg-surface px-3 py-2.5">
      <p className="text-xs font-medium uppercase tracking-wider text-subtle">
        {label}
      </p>
      <p className="font-display text-xl font-medium tabular-nums text-fg">{value}</p>
    </div>
  );
}

function Chip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "h-9 shrink-0 rounded-full border px-3 text-sm transition-colors duration-150",
        active
          ? "border-accent bg-accent text-accent-fg"
          : "border-border bg-elevated text-muted hover:text-fg",
      )}
    >
      {children}
    </button>
  );
}

function Th({
  children,
  className,
}: {
  children?: ReactNode;
  className?: string;
}) {
  return <th className={cn("px-3 py-3 font-medium", className)}>{children}</th>;
}

function SortTh({
  k,
  current,
  dir,
  onClick,
  children,
}: {
  k: SortKey;
  current: SortKey;
  dir: "asc" | "desc";
  onClick: (k: SortKey) => void;
  children: ReactNode;
}) {
  const active = current === k;
  return (
    <th className="px-3 py-3">
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          onClick(k);
        }}
        className={cn(
          "inline-flex items-center gap-1 font-medium",
          active ? "text-fg" : "text-subtle hover:text-fg",
        )}
      >
        {children}
        {active ? (
          dir === "desc" ? (
            <ArrowDown className="size-3.5" />
          ) : (
            <ArrowUp className="size-3.5" />
          )
        ) : null}
      </button>
    </th>
  );
}

function DrunkToggle({
  drunk,
  onToggle,
}: {
  drunk: boolean;
  onToggle: () => void;
}) {
  return (
    <span
      role="checkbox"
      aria-checked={drunk}
      aria-label={drunk ? "Smagt" : "Ikke smagt"}
      tabIndex={0}
      onClick={(e) => {
        e.stopPropagation();
        onToggle();
      }}
      onKeyDown={(e) => {
        if (e.key === " " || e.key === "Enter") {
          e.preventDefault();
          e.stopPropagation();
          onToggle();
        }
      }}
      className={cn(
        "inline-flex size-8 items-center justify-center rounded-sm border transition-colors duration-150",
        drunk
          ? "border-accent bg-accent text-accent-fg"
          : "border-border bg-elevated text-transparent hover:border-accent/50",
      )}
    >
      <Check className="size-4" strokeWidth={3} />
    </span>
  );
}

function UntappdCell({ beer }: { beer: Beer }) {
  return (
    <a
      href={beer.untappdUrl}
      target="_blank"
      rel="noreferrer"
      onClick={(e) => e.stopPropagation()}
      className="inline-flex items-center gap-1 font-mono text-sm tabular-nums text-rating hover:underline"
    >
      {formatRating(beer.untappdRating)}
      <ExternalLink className="size-3 opacity-70" />
    </a>
  );
}

function FriendPills({
  beerId,
  members,
  activeId,
  checkinFor,
}: {
  beerId: string;
  members: { id: string; name: string }[];
  activeId: string;
  checkinFor: (memberId: string, beerId: string) => { drunk: boolean; score: number | null };
}) {
  const friends = members.filter(
    (m) => m.id !== activeId && checkinFor(m.id, beerId).drunk,
  );
  if (friends.length === 0) return <span className="text-xs text-subtle">–</span>;
  return (
    <span className="flex flex-wrap gap-1">
      {friends.map((m) => {
        const c = checkinFor(m.id, beerId);
        return (
          <span
            key={m.id}
            title={`${m.name || "Ven"} ${c.score ?? ""}`}
            className="inline-flex items-center gap-1 rounded-full bg-elevated px-1.5 py-0.5 font-mono text-xs tabular-nums text-muted"
          >
            {initials(m.name || "Ven")}
            {c.score != null ? ` ${c.score.toFixed(1)}` : ""}
          </span>
        );
      })}
    </span>
  );
}

function CrewPanel({
  members,
  activeId,
  friendName,
  onFriendName,
  onSubmitFriend,
  onActive,
  onRename,
  onRemove,
}: {
  members: { id: string; name: string }[];
  activeId: string;
  friendName: string;
  onFriendName: (v: string) => void;
  onSubmitFriend: () => void;
  onActive: (id: string) => void;
  onRename: (id: string, name: string) => void;
  onRemove: (id: string) => void;
}) {
  const active = members.find((m) => m.id === activeId) ?? members[0];
  return (
    <div className="rounded-xl border border-border bg-surface p-4">
      <p className="text-xs font-medium uppercase tracking-wider text-subtle">
        Holdet
      </p>
      <label className="mt-3 block text-sm text-muted">
        Dit navn
        <Input
          className="mt-1.5"
          value={active.name}
          placeholder="Skriv dit navn"
          onChange={(e) => onRename(active.id, e.target.value)}
        />
      </label>
      <div className="mt-3 flex flex-wrap gap-2">
        {members.map((m) => (
          <button
            key={m.id}
            type="button"
            onClick={() => onActive(m.id)}
            className={cn(
              "inline-flex h-9 items-center gap-2 rounded-full border px-3 text-sm",
              m.id === activeId
                ? "border-accent bg-accent text-accent-fg"
                : "border-border bg-elevated text-muted",
            )}
          >
            {m.name || (m.id === members[0].id ? "Dig" : "Ven")}
            {m.id !== members[0].id ? (
              <span
                role="button"
                tabIndex={0}
                aria-label="Fjern"
                onClick={(e) => {
                  e.stopPropagation();
                  onRemove(m.id);
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") onRemove(m.id);
                }}
              >
                <X className="size-3.5" />
              </span>
            ) : null}
          </button>
        ))}
      </div>
      <form
        className="mt-3 flex gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          onSubmitFriend();
        }}
      >
        <Input
          value={friendName}
          onChange={(e) => onFriendName(e.target.value)}
          placeholder="Tilføj ven"
        />
        <Button type="submit" size="icon" aria-label="Tilføj ven">
          <Plus className="size-4" />
        </Button>
      </form>
      <p className="mt-2 text-xs text-subtle">
        Skift aktiv person for at tjekke ind og score på deres vegne — nemt ved
        bordet i hallen.
      </p>
    </div>
  );
}

function BeerDetail({
  beer,
  mine,
  members,
  activeId,
  checkinFor,
  onDrunk,
  onScore,
  onWant,
  onClose,
}: {
  beer: Beer;
  mine: { drunk: boolean; score: number | null; want: boolean };
  members: { id: string; name: string }[];
  activeId: string;
  checkinFor: (memberId: string, beerId: string) => { drunk: boolean; score: number | null };
  onDrunk: (v: boolean) => void;
  onScore: (v: number | null) => void;
  onWant: (v: boolean) => void;
  onClose: () => void;
}) {
  const friends = members.filter((m) => m.id !== activeId);
  return (
    <div className="overflow-y-auto px-5 pt-3 pb-[max(1.5rem,env(safe-area-inset-bottom))]">
      <div className="flex items-start justify-between gap-3">
        <div>
          <Drawer.Title className="font-display text-2xl font-medium uppercase tracking-tight text-fg">
            {beer.name}
          </Drawer.Title>
          <Drawer.Description className="mt-1 text-sm text-muted">
            {beer.brewery} · {beer.country} · {beer.style}
          </Drawer.Description>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="flex size-10 items-center justify-center rounded-md text-muted hover:text-fg"
          aria-label="Luk"
        >
          <X className="size-5" />
        </button>
      </div>

      <div className="mt-4 grid grid-cols-3 gap-2">
        <Meta label="ABV" value={formatAbv(beer.abv)} />
        <Meta label="IBU" value={beer.ibu == null ? "–" : String(beer.ibu)} />
        <Meta
          label="Untappd"
          value={
            beer.untappdRating == null
              ? "–"
              : `${formatRating(beer.untappdRating)}${beer.untappdCount ? ` (${beer.untappdCount})` : ""}`
          }
        />
      </div>

      <div className="mt-5 flex gap-2">
        <Button
          type="button"
          variant={mine.drunk ? "primary" : "secondary"}
          className="flex-1"
          onClick={() => onDrunk(!mine.drunk)}
        >
          <Check className="size-4" />
          {mine.drunk ? "Smagt" : "Kryds af"}
        </Button>
        <Button
          type="button"
          variant={mine.want ? "primary" : "secondary"}
          size="icon"
          aria-label="Skal smages"
          onClick={() => onWant(!mine.want)}
        >
          <Bookmark className={cn("size-4", mine.want && "fill-current")} />
        </Button>
        <a
          href={beer.untappdUrl}
          target="_blank"
          rel="noreferrer"
          className="inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-md border border-border bg-elevated px-4 text-sm font-medium text-fg"
        >
          Untappd
          <ExternalLink className="size-4" />
        </a>
      </div>

      <div className="mt-5">
        <ScoreControl value={mine.score} onChange={onScore} />
      </div>

      {friends.length > 0 ? (
        <div className="mt-6">
          <p className="text-xs font-medium uppercase tracking-wider text-subtle">
            Holdet
          </p>
          <ul className="mt-2 divide-y divide-border">
            {friends.map((m) => {
              const c = checkinFor(m.id, beer.id);
              return (
                <li key={m.id} className="flex items-center justify-between py-2.5 text-sm">
                  <span className="text-fg">{m.name || "Ven"}</span>
                  <span className="font-mono tabular-nums text-muted">
                    {c.drunk
                      ? c.score != null
                        ? c.score.toFixed(2)
                        : "Smagt"
                      : "Ikke smagt"}
                  </span>
                </li>
              );
            })}
          </ul>
        </div>
      ) : (
        <p className="mt-6 text-sm text-subtle">
          Tilføj venner under holdet for at se deres scores ved siden af dine.
        </p>
      )}
    </div>
  );
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-border bg-elevated px-3 py-2">
      <p className="text-xs uppercase tracking-wider text-subtle">{label}</p>
      <p className="font-mono text-sm tabular-nums text-fg">{value}</p>
    </div>
  );
}
