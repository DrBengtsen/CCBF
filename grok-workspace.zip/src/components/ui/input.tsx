import { type InputHTMLAttributes, forwardRef } from "react";
import { cn } from "@/lib/utils";

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(
  function Input({ className, ...props }, ref) {
    return (
      <input
        ref={ref}
        className={cn(
          "h-11 w-full rounded-md border border-border bg-elevated px-3 text-sm text-fg placeholder:text-subtle",
          "transition-[border-color,box-shadow] duration-150",
          "focus:border-accent/60 focus:outline-none focus:ring-2 focus:ring-accent/30",
          className,
        )}
        {...props}
      />
    );
  },
);
