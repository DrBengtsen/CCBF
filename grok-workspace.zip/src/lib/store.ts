import { create } from "zustand";
import { persist } from "zustand/middleware";
import { uid } from "@/lib/utils";

export type Checkin = {
  drunk: boolean;
  score: number | null;
  want: boolean;
};

export type Member = {
  id: string;
  name: string;
};

type CrewState = {
  members: Member[];
  activeId: string;
  checkins: Record<string, Record<string, Checkin>>;
  setActive: (id: string) => void;
  rename: (id: string, name: string) => void;
  addFriend: (name: string) => void;
  removeMember: (id: string) => void;
  setDrunk: (beerId: string, drunk: boolean) => void;
  setScore: (beerId: string, score: number | null) => void;
  setWant: (beerId: string, want: boolean) => void;
  checkinFor: (memberId: string, beerId: string) => Checkin;
};

const empty = (): Checkin => ({ drunk: false, score: null, want: false });

function firstMember(): Member {
  return { id: "me", name: "" };
}

export const useCrew = create<CrewState>()(
  persist(
    (set, get) => {
      const me = firstMember();
      return {
        members: [me],
        activeId: me.id,
        checkins: {},
        setActive: (id) => set({ activeId: id }),
        rename: (id, name) =>
          set((s) => ({
            members: s.members.map((m) => (m.id === id ? { ...m, name } : m)),
          })),
        addFriend: (name) => {
          const friend: Member = { id: uid(), name: name.trim() };
          if (!friend.name) return;
          set((s) => ({ members: [...s.members, friend], activeId: friend.id }));
        },
        removeMember: (id) =>
          set((s) => {
            if (s.members.length === 1) return s;
            const members = s.members.filter((m) => m.id !== id);
            const checkins = { ...s.checkins };
            delete checkins[id];
            const activeId = s.activeId === id ? members[0].id : s.activeId;
            return { members, checkins, activeId };
          }),
        setDrunk: (beerId, drunk) => {
          const { activeId, checkins } = get();
          const mine = { ...(checkins[activeId] ?? {}) };
          const cur = mine[beerId] ?? empty();
          mine[beerId] = { ...cur, drunk, score: drunk ? cur.score : null };
          set({ checkins: { ...checkins, [activeId]: mine } });
        },
        setScore: (beerId, score) => {
          const { activeId, checkins } = get();
          const mine = { ...(checkins[activeId] ?? {}) };
          const cur = mine[beerId] ?? empty();
          mine[beerId] = {
            ...cur,
            score,
            drunk: score != null ? true : cur.drunk,
          };
          set({ checkins: { ...checkins, [activeId]: mine } });
        },
        setWant: (beerId, want) => {
          const { activeId, checkins } = get();
          const mine = { ...(checkins[activeId] ?? {}) };
          const cur = mine[beerId] ?? empty();
          mine[beerId] = { ...cur, want };
          set({ checkins: { ...checkins, [activeId]: mine } });
        },
        checkinFor: (memberId, beerId) =>
          get().checkins[memberId]?.[beerId] ?? empty(),
      };
    },
    { name: "ccbf-2026-crew" },
  ),
);
