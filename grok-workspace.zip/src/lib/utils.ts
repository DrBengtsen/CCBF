import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatAbv(abv: number | null): string {
  if (abv == null) return "–";
  return `${abv.toLocaleString("da-DK", { minimumFractionDigits: abv % 1 === 0 ? 0 : 1, maximumFractionDigits: 1 })}%`;
}

export function formatRating(rating: number | null): string {
  if (rating == null) return "–";
  return rating.toFixed(2);
}

export function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "?";
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

export function uid(): string {
  return crypto.randomUUID();
}
