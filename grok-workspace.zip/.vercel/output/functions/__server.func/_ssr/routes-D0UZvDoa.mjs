import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as ExternalLink, c as ArrowUp, i as Plus, l as ArrowDown, o as Check, r as Search, s as Bookmark, t as X } from "../_libs/lucide-react.mjs";
import { t as Drawer } from "../_libs/vaul.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D0UZvDoa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function u(brewery, name) {
	return `https://untappd.com/search?q=${encodeURIComponent(`${name} ${brewery}`)}`;
}
function b(partial) {
	return {
		...partial,
		untappdUrl: u(partial.brewery, partial.name)
	};
}
var BEERS = [
	b({
		id: "hopeful",
		name: "(HOP)eful",
		brewery: "EDIT Brewing",
		country: "Italien",
		countryCode: "IT",
		style: "Pacific IPA",
		family: "ipa",
		abv: 6,
		ibu: 33,
		untappdRating: 3.79,
		untappdCount: 16
	}),
	b({
		id: "five-minute-window",
		name: "5 Minute Window",
		brewery: "Wild Raccoon",
		country: "Italien",
		countryCode: "IT",
		style: "American IPA",
		family: "ipa",
		abv: 6.8,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "ajuvaba-astelpaju",
		name: "Ajuvaba Astelpaju",
		brewery: "Humalakoda Pruulikoda",
		country: "Estland",
		countryCode: "EE",
		style: "Sour Ale · havtorn",
		family: "sour",
		abv: 4.3,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "american-hype",
		name: "American Hype",
		brewery: "Birrificio Lariano",
		country: "Italien",
		countryCode: "IT",
		style: "American IPA",
		family: "ipa",
		abv: 6.7,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "anti-hero",
		name: "Anti Hero",
		brewery: "Deeper Roots Brewing",
		country: "Danmark",
		countryCode: "DK",
		style: "American IPA",
		family: "ipa",
		abv: 6.2,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "biere-pacifique",
		name: "Bière Pacifique",
		brewery: "Eternal Night Brewing",
		country: "Estland",
		countryCode: "EE",
		style: "Belgian Pale Ale",
		family: "pale",
		abv: 4,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "big-black-cock",
		name: "Big Black Cock",
		brewery: "AnAle.Works",
		country: "Danmark",
		countryCode: "DK",
		style: "Imperial Stout",
		family: "stout",
		abv: 9.5,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "black-domina",
		name: "Black Domina",
		brewery: "Christiania Bryghus",
		country: "Danmark",
		countryCode: "DK",
		style: "Imperial Coffee Stout",
		family: "stout",
		abv: 10,
		ibu: 97,
		untappdRating: 3.75,
		untappdCount: 386
	}),
	b({
		id: "border-control",
		name: "Border Control",
		brewery: "Undercover Brewing Co.",
		country: "Danmark",
		countryCode: "DK",
		style: "Hazy DIPA",
		family: "ipa",
		abv: 7.7,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "undercover-brown",
		name: "Brown Ale",
		brewery: "Undercover Brewing Co.",
		country: "Danmark",
		countryCode: "DK",
		style: "Brown Ale",
		family: "other",
		abv: 5.4,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "buzdygan-2026",
		name: "Buzdygan Rozkoszy 2026",
		brewery: "Harpagan Craft Beer",
		country: "Polen",
		countryCode: "PL",
		style: "Imperial Pastry Stout",
		family: "stout",
		abv: 9.8,
		ibu: null,
		untappdRating: 4,
		untappdCount: 356
	}),
	b({
		id: "choco-comet",
		name: "Choco Comet",
		brewery: "Green Head",
		country: "Polen",
		countryCode: "PL",
		style: "Chocolate Cold Imperial Stout",
		family: "stout",
		abv: 10,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "citrust",
		name: "Citrust",
		brewery: "EDIT Brewing",
		country: "Italien",
		countryCode: "IT",
		style: "Fruity APA",
		family: "pale",
		abv: 5.3,
		ibu: 50,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "cosmic",
		name: "Cosmic",
		brewery: "Perfectly Squared",
		country: "Sverige",
		countryCode: "SE",
		style: "Imperial / Double IPA",
		family: "ipa",
		abv: 8.5,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "crispy-corey",
		name: "Crispy Corey",
		brewery: "Anchorman Brewing",
		country: "Danmark",
		countryCode: "DK",
		style: "Cold IPA",
		family: "ipa",
		abv: 6.2,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "cross-your-heart",
		name: "Cross Your Heart",
		brewery: "Wild Raccoon",
		country: "Italien",
		countryCode: "IT",
		style: "New England / Hazy IPA",
		family: "ipa",
		abv: 6.6,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "early-bird-neipa",
		name: "Early Bird NEIPA",
		brewery: "FIRST Craft Beer",
		country: "Ungarn",
		countryCode: "HU",
		style: "New England IPA",
		family: "ipa",
		abv: 6.5,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "few-more-beers",
		name: "Few More Beers",
		brewery: "TankBusters",
		country: "Polen",
		countryCode: "PL",
		style: "TDH Double NEIPA",
		family: "ipa",
		abv: 8.4,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "fuel-to-fire",
		name: "Fuel To Fire",
		brewery: "Amager Bryghus",
		country: "Danmark",
		countryCode: "DK",
		style: "Imperial Pastry Stout",
		family: "stout",
		abv: 18.5,
		ibu: 40,
		untappdRating: 3.92,
		untappdCount: 1278
	}),
	b({
		id: "gone-mental",
		name: "Gone Mental",
		brewery: "Antikorpo Brewing Co.",
		country: "Italien",
		countryCode: "IT",
		style: "Imperial Pastry Stout",
		family: "stout",
		abv: 7.5,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "grabovia",
		name: "Grabovia",
		brewery: "Birrificio del Catria",
		country: "Italien",
		countryCode: "IT",
		style: "Russian Imperial Stout",
		family: "stout",
		abv: 9.5,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "green-screen",
		name: "Green Screen",
		brewery: "TankBusters",
		country: "Polen",
		countryCode: "PL",
		style: "DDH New England IPA",
		family: "ipa",
		abv: 6.2,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "havtorn-milkshake",
		name: "Havtorn Milkshake",
		brewery: "Musicon Mikrobryggeri",
		country: "Danmark",
		countryCode: "DK",
		style: "Berliner Weisse · havtorn & laktose",
		family: "sour",
		abv: 5.5,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "hell-hunt-xxx",
		name: "Hell Hunt XXX",
		brewery: "Humalakoda Pruulikoda",
		country: "Estland",
		countryCode: "EE",
		style: "Triple IPA",
		family: "ipa",
		abv: 10,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "heres-honey",
		name: "Here's Honey",
		brewery: "Malmö Brewing Co.",
		country: "Sverige",
		countryCode: "SE",
		style: "Session Mead",
		family: "mead",
		abv: 6,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "italian-stallion",
		name: "Italian Stallion",
		brewery: "AnAle.Works",
		country: "Danmark",
		countryCode: "DK",
		style: "Italian Lager",
		family: "lager",
		abv: 4.8,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "juicy-mango",
		name: "JUICY Mango Passionfruit",
		brewery: "Recraft",
		country: "Polen",
		countryCode: "PL",
		style: "Sweet Sour Fruit Ale",
		family: "sour",
		abv: 4,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "kisel",
		name: "Kisel: Passion Fruit & Mango",
		brewery: "Sofia Electric Brewing",
		country: "Bulgarien",
		countryCode: "BG",
		style: "Fruited Gose",
		family: "sour",
		abv: 3.8,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "kombu",
		name: "Kombu",
		brewery: "Deeper Roots Brewing",
		country: "Danmark",
		countryCode: "DK",
		style: "Irish Dry Stout",
		family: "stout",
		abv: 5.5,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "la-grigna",
		name: "La Grigna",
		brewery: "Birrificio Lariano",
		country: "Italien",
		countryCode: "IT",
		style: "Italian Pils",
		family: "lager",
		abv: 4.6,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "lowrider",
		name: "Lowrider",
		brewery: "Antikorpo Brewing Co.",
		country: "Italien",
		countryCode: "IT",
		style: "India Pale Lager",
		family: "lager",
		abv: 5.8,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "night-harvest",
		name: "Night Harvest",
		brewery: "Rockmill",
		country: "Polen",
		countryCode: "PL",
		style: "Cardamom & Coffee Stout",
		family: "stout",
		abv: 7.2,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "no-name",
		name: "No Name",
		brewery: "Anchorman Brewing",
		country: "Danmark",
		countryCode: "DK",
		style: "Witbier · lemongrass & kamille",
		family: "wheat",
		abv: null,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "ottos-express",
		name: "Ottos Express",
		brewery: "Malmö Brewing Co.",
		country: "Sverige",
		countryCode: "SE",
		style: "Hazy IPA",
		family: "ipa",
		abv: 6.4,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "outburst",
		name: "Outburst",
		brewery: "Stepping Stone Brewing Co.",
		country: "Danmark",
		countryCode: "DK",
		style: "DDH Double IPA",
		family: "ipa",
		abv: 8.2,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "overflow",
		name: "Overflow",
		brewery: "Sofia Electric Brewing",
		country: "Bulgarien",
		countryCode: "BG",
		style: "IPA",
		family: "ipa",
		abv: 6.7,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "pacific-pusher",
		name: "Pacific Pusher",
		brewery: "Christiania Bryghus",
		country: "Danmark",
		countryCode: "DK",
		style: "New England Hazy IPA",
		family: "ipa",
		abv: 6.5,
		ibu: 19,
		untappdRating: 4.05,
		untappdCount: 21
	}),
	b({
		id: "pearfection",
		name: "Pearfection",
		brewery: "Nurme Brewery",
		country: "Estland",
		countryCode: "EE",
		style: "Pear & Apricot Double Gose",
		family: "sour",
		abv: 8,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "polish-hops",
		name: "Polish Hops",
		brewery: "Recraft",
		country: "Polen",
		countryCode: "PL",
		style: "Hazy IPA",
		family: "ipa",
		abv: 5.1,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "powab-oprycha",
		name: "Powab Oprycha 2026",
		brewery: "Harpagan Craft Beer",
		country: "Polen",
		countryCode: "PL",
		style: "Imperial Double NEIPA",
		family: "ipa",
		abv: 7.5,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "rhapsody",
		name: "Rhapsody",
		brewery: "Green Head",
		country: "Polen",
		countryCode: "PL",
		style: "Cold IPA",
		family: "ipa",
		abv: 7,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "rocket-queen",
		name: "Rocket Queen",
		brewery: "Green Gold Brewing",
		country: "Slovenien",
		countryCode: "SI",
		style: "American IPA",
		family: "ipa",
		abv: 6.9,
		ibu: 55,
		untappdRating: 3.56,
		untappdCount: 5572
	}),
	b({
		id: "rod-lober",
		name: "Rød Løber",
		brewery: "Musicon Mikrobryggeri",
		country: "Danmark",
		countryCode: "DK",
		style: "American Pale Ale",
		family: "pale",
		abv: 5.6,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "santamasa",
		name: "Santamasa Laphroaig",
		brewery: "FIRST Craft Beer",
		country: "Ungarn",
		countryCode: "HU",
		style: "BA Barley Wine",
		family: "other",
		abv: 11.5,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "silence",
		name: "Silence",
		brewery: "Eternal Night Brewing",
		country: "Estland",
		countryCode: "EE",
		style: "Belgian Imperial Stout",
		family: "stout",
		abv: 8,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "so-it-goes",
		name: "So It Goes",
		brewery: "Proton Brewery",
		country: "Sverige",
		countryCode: "SE",
		style: "Traditional Gose",
		family: "sour",
		abv: 4.7,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "stormbringer",
		name: "Stormbringer",
		brewery: "Amager Bryghus",
		country: "Danmark",
		countryCode: "DK",
		style: "Dry-hopped Hazy DIPA",
		family: "ipa",
		abv: 8.2,
		ibu: 29,
		untappdRating: 3.82,
		untappdCount: 1685
	}),
	b({
		id: "tekvia",
		name: "Tekvia",
		brewery: "Birrificio del Catria",
		country: "Italien",
		countryCode: "IT",
		style: "Session APA",
		family: "pale",
		abv: 3.9,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "ne-white-dipa",
		name: "New England White DIPA",
		brewery: "Rockmill",
		country: "Polen",
		countryCode: "PL",
		style: "New England White DIPA",
		family: "ipa",
		abv: 7.8,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "tidebreak",
		name: "Tidebreak",
		brewery: "Perfectly Squared",
		country: "Sverige",
		countryCode: "SE",
		style: "Session NEIPA",
		family: "ipa",
		abv: 4.5,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "tidsfordriv",
		name: "Tidsfördriv",
		brewery: "Proton Brewery",
		country: "Sverige",
		countryCode: "SE",
		style: "Brown Ale",
		family: "other",
		abv: 6.6,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "tropikalia",
		name: "Tropikalia",
		brewery: "White Stork Beer Co.",
		country: "Bulgarien",
		countryCode: "BG",
		style: "NEIPA",
		family: "ipa",
		abv: 7,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "turbo-rocket-queen",
		name: "Turbo Rocket Queen",
		brewery: "Green Gold Brewing",
		country: "Slovenien",
		countryCode: "SI",
		style: "Double Imperial IPA",
		family: "ipa",
		abv: 10,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "twilight-to-starlight",
		name: "Twilight To Starlight",
		brewery: "Nurme Brewery",
		country: "Estland",
		countryCode: "EE",
		style: "Lushly Dry Hopped DIPA",
		family: "ipa",
		abv: 8,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "white-stout",
		name: "White Stout",
		brewery: "White Stork Beer Co.",
		country: "Bulgarien",
		countryCode: "BG",
		style: "White Stout",
		family: "stout",
		abv: 7,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	}),
	b({
		id: "whoosh",
		name: "Whoosh",
		brewery: "Stepping Stone Brewing Co.",
		country: "Danmark",
		countryCode: "DK",
		style: "West Coast IPA",
		family: "ipa",
		abv: 6.7,
		ibu: null,
		untappdRating: null,
		untappdCount: null
	})
];
var DIRECT = {
	"fuel-to-fire": "https://untappd.com/b/amager-bryghus-fuel-to-fire/3178798",
	stormbringer: "https://untappd.com/b/amager-bryghus-stormbringer/6552195",
	"pacific-pusher": "https://untappd.com/b/christiania-bryghus-pacific-pusher/6481563",
	"black-domina": "https://untappd.com/b/christiania-bryghus-black-domina/5162720",
	"buzdygan-2026": "https://untappd.com/b/harpagan-craft-beer-buzdygan-rozkoszy-2026/6620595",
	"rocket-queen": "https://untappd.com/b/green-gold-brewing-rocket-queen/1645609"
};
for (const beer of BEERS) if (DIRECT[beer.id]) beer.untappdUrl = DIRECT[beer.id];
var FAMILY_LABEL = {
	ipa: "IPA",
	stout: "Stout / porter",
	sour: "Sour",
	lager: "Lager / pils",
	pale: "Pale ale",
	wheat: "Hvede",
	mead: "Mjød",
	other: "Andet"
};
var BREWERIES = [...new Set(BEERS.map((x) => x.brewery))].sort((a, b) => a.localeCompare(b, "da"));
[...new Set(BEERS.map((x) => x.country))].sort((a, b) => a.localeCompare(b, "da"));
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function formatAbv(abv) {
	if (abv == null) return "–";
	return `${abv.toLocaleString("da-DK", {
		minimumFractionDigits: abv % 1 === 0 ? 0 : 1,
		maximumFractionDigits: 1
	})}%`;
}
function formatRating(rating) {
	if (rating == null) return "–";
	return rating.toFixed(2);
}
function initials(name) {
	const parts = name.trim().split(/\s+/).filter(Boolean);
	if (parts.length === 0) return "?";
	if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
	return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}
function uid() {
	return crypto.randomUUID();
}
var empty = () => ({
	drunk: false,
	score: null,
	want: false
});
function firstMember() {
	return {
		id: "me",
		name: ""
	};
}
var useCrew = create()(persist((set, get) => {
	const me = firstMember();
	return {
		members: [me],
		activeId: me.id,
		checkins: {},
		setActive: (id) => set({ activeId: id }),
		rename: (id, name) => set((s) => ({ members: s.members.map((m) => m.id === id ? {
			...m,
			name
		} : m) })),
		addFriend: (name) => {
			const friend = {
				id: uid(),
				name: name.trim()
			};
			if (!friend.name) return;
			set((s) => ({
				members: [...s.members, friend],
				activeId: friend.id
			}));
		},
		removeMember: (id) => set((s) => {
			if (s.members.length === 1) return s;
			const members = s.members.filter((m) => m.id !== id);
			const checkins = { ...s.checkins };
			delete checkins[id];
			return {
				members,
				checkins,
				activeId: s.activeId === id ? members[0].id : s.activeId
			};
		}),
		setDrunk: (beerId, drunk) => {
			const { activeId, checkins } = get();
			const mine = { ...checkins[activeId] ?? {} };
			const cur = mine[beerId] ?? empty();
			mine[beerId] = {
				...cur,
				drunk,
				score: drunk ? cur.score : null
			};
			set({ checkins: {
				...checkins,
				[activeId]: mine
			} });
		},
		setScore: (beerId, score) => {
			const { activeId, checkins } = get();
			const mine = { ...checkins[activeId] ?? {} };
			const cur = mine[beerId] ?? empty();
			mine[beerId] = {
				...cur,
				score,
				drunk: score != null ? true : cur.drunk
			};
			set({ checkins: {
				...checkins,
				[activeId]: mine
			} });
		},
		setWant: (beerId, want) => {
			const { activeId, checkins } = get();
			const mine = { ...checkins[activeId] ?? {} };
			mine[beerId] = {
				...mine[beerId] ?? empty(),
				want
			};
			set({ checkins: {
				...checkins,
				[activeId]: mine
			} });
		},
		checkinFor: (memberId, beerId) => get().checkins[memberId]?.[beerId] ?? empty()
	};
}, { name: "ccbf-2026-crew" }));
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium transition-[opacity,transform,background-color,color,border-color] duration-[var(--motion-quick,150ms)] ease-[cubic-bezier(0.22,1,0.36,1)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/70 disabled:pointer-events-none disabled:opacity-40 active:scale-[0.98]", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg hover:opacity-90",
			secondary: "bg-elevated text-fg border border-border hover:border-accent/40",
			ghost: "bg-transparent text-muted hover:text-fg hover:bg-elevated",
			danger: "bg-danger text-fg hover:opacity-90"
		},
		size: {
			sm: "h-9 px-3 text-sm rounded-sm",
			md: "h-11 px-4 text-sm rounded-md",
			lg: "h-12 px-5 text-base rounded-md",
			icon: "size-11 rounded-md"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
var Button = (0, import_react.forwardRef)(function Button({ className, variant, size, ...props }, ref) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		ref,
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
});
var Input = (0, import_react.forwardRef)(function Input({ className, ...props }, ref) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		ref,
		className: cn("h-11 w-full rounded-md border border-border bg-elevated px-3 text-sm text-fg placeholder:text-subtle", "transition-[border-color,box-shadow] duration-150", "focus:border-accent/60 focus:outline-none focus:ring-2 focus:ring-accent/30", className),
		...props
	});
});
function HopMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className,
		"aria-hidden": "true",
		fill: "none",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 3c1.4 3.2 3.8 5.4 7 6.6-2.1 1.6-3.6 3.8-4.4 6.4 1.8-.6 3.6-.8 5.4-.4-1.6 3.4-4.4 5.8-8 6.8 3.6 1 6.4 3.4 8 6.8-1.8.4-3.6.2-5.4-.4.8 2.6 2.3 4.8 4.4 6.4-3.2 1.2-5.6 3.4-7 6.6-1.4-3.2-3.8-5.4-7-6.6 2.1-1.6 3.6-3.8 4.4-6.4-1.8.6-3.6.8-5.4.4 1.6-3.4 4.4-5.8 8-6.8-3.6-1-6.4-3.4-8-6.8 1.8-.4 3.6-.2 5.4.4C9.2 13.4 7.7 11.2 5.6 9.6 8.8 8.4 11.2 6.2 12.6 3h3.4Z",
			transform: "scale(.72) translate(6.2 2.2)",
			stroke: "currentColor",
			strokeWidth: "1.6",
			strokeLinejoin: "round"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 8v16",
			stroke: "currentColor",
			strokeWidth: "1.4",
			strokeLinecap: "round"
		})]
	});
}
var STEPS = [
	.5,
	1,
	1.5,
	2,
	2.5,
	3,
	3.5,
	4,
	4.5,
	5
];
function ScoreControl({ value, onChange, compact }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2",
		children: [!compact ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-baseline justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs font-medium uppercase tracking-wider text-subtle",
				children: "Din score"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-sm tabular-nums text-rating",
				children: value == null ? "–" : value.toFixed(2)
			})]
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("flex flex-wrap gap-1", compact && "justify-end"),
			children: STEPS.map((step) => {
				const active = value != null && value >= step;
				const exact = value === step;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": `Sæt score ${step}`,
					onClick: () => onChange(value === step ? null : step),
					className: cn("min-w-8 rounded-sm px-1.5 font-mono text-xs tabular-nums transition-colors duration-150", compact ? "h-8" : "h-9", exact ? "bg-rating text-accent-fg" : active ? "bg-rating/25 text-rating" : "bg-elevated text-subtle hover:text-fg"),
					children: step % 1 === 0 ? step.toFixed(0) : step.toFixed(1)
				}, step);
			})
		})]
	});
}
function ScoreBadge({ score }) {
	if (score == null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "font-mono text-xs tabular-nums text-subtle",
		children: "–"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "font-mono text-sm font-semibold tabular-nums text-rating",
		children: score.toFixed(2)
	});
}
var FAMILIES = [
	"ipa",
	"stout",
	"sour",
	"lager",
	"pale",
	"wheat",
	"mead",
	"other"
];
function FestivalApp() {
	const members = useCrew((s) => s.members);
	const activeId = useCrew((s) => s.activeId);
	const setActive = useCrew((s) => s.setActive);
	const rename = useCrew((s) => s.rename);
	const addFriend = useCrew((s) => s.addFriend);
	const removeMember = useCrew((s) => s.removeMember);
	const checkins = useCrew((s) => s.checkins);
	const checkinFor = useCrew((s) => s.checkinFor);
	const setDrunk = useCrew((s) => s.setDrunk);
	const setScore = useCrew((s) => s.setScore);
	const setWant = useCrew((s) => s.setWant);
	const active = members.find((m) => m.id === activeId) ?? members[0];
	const [query, setQuery] = (0, import_react.useState)("");
	const [family, setFamily] = (0, import_react.useState)("all");
	const [brewery, setBrewery] = (0, import_react.useState)("all");
	const [drunkFilter, setDrunkFilter] = (0, import_react.useState)("all");
	const [sortKey, setSortKey] = (0, import_react.useState)("untappd");
	const [sortDir, setSortDir] = (0, import_react.useState)("desc");
	const [selectedId, setSelectedId] = (0, import_react.useState)(null);
	const [friendName, setFriendName] = (0, import_react.useState)("");
	const [crewOpen, setCrewOpen] = (0, import_react.useState)(false);
	const selected = BEERS.find((b) => b.id === selectedId) ?? null;
	const rows = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		const list = BEERS.filter((beer) => {
			if (family !== "all" && beer.family !== family) return false;
			if (brewery !== "all" && beer.brewery !== brewery) return false;
			const mine = checkinFor(activeId, beer.id);
			const friendsDrank = members.some((m) => m.id !== activeId && checkinFor(m.id, beer.id).drunk);
			if (drunkFilter === "mine" && !mine.drunk) return false;
			if (drunkFilter === "todo" && mine.drunk) return false;
			if (drunkFilter === "want" && !mine.want) return false;
			if (drunkFilter === "friends" && !friendsDrank) return false;
			if (!q) return true;
			return beer.name.toLowerCase().includes(q) || beer.brewery.toLowerCase().includes(q) || beer.style.toLowerCase().includes(q) || beer.country.toLowerCase().includes(q);
		});
		const dir = sortDir === "asc" ? 1 : -1;
		list.sort((a, b) => {
			const mineA = checkinFor(activeId, a.id);
			const mineB = checkinFor(activeId, b.id);
			switch (sortKey) {
				case "name": return dir * a.name.localeCompare(b.name, "da");
				case "brewery": return dir * a.brewery.localeCompare(b.brewery, "da");
				case "style": return dir * a.style.localeCompare(b.style, "da");
				case "abv": return dir * ((a.abv ?? -1) - (b.abv ?? -1));
				case "mine": return dir * ((mineA.score ?? -1) - (mineB.score ?? -1));
				case "drunk": return dir * (Number(mineA.drunk) - Number(mineB.drunk));
				default: {
					const ra = a.untappdRating ?? -1;
					const rb = b.untappdRating ?? -1;
					if (ra === rb) return a.name.localeCompare(b.name, "da");
					return dir * (ra - rb);
				}
			}
		});
		return list;
	}, [
		query,
		family,
		brewery,
		drunkFilter,
		sortKey,
		sortDir,
		activeId,
		checkins,
		members,
		checkinFor
	]);
	const tasted = BEERS.filter((beer) => checkinFor(activeId, beer.id).drunk).length;
	const scores = BEERS.map((beer) => checkinFor(activeId, beer.id).score).filter((s) => s != null);
	const avg = scores.length ? scores.reduce((a, n) => a + n, 0) / scores.length : null;
	function toggleSort(key) {
		if (sortKey === key) setSortDir((d) => d === "desc" ? "asc" : "desc");
		else {
			setSortKey(key);
			setSortDir(key === "name" || key === "brewery" || key === "style" ? "asc" : "desc");
		}
	}
	function submitFriend() {
		if (!friendName.trim()) return;
		addFriend(friendName.trim());
		setFriendName("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "border-b border-border/80 bg-bg/80 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col gap-5 px-4 py-5 sm:px-6 sm:py-7",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-0.5 flex size-11 items-center justify-center rounded-lg border border-border bg-elevated text-accent",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HopMark, { className: "size-6" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-[11px] font-medium uppercase tracking-[0.22em] text-accent",
										children: "Den Grå Hal · 19. sep 2026"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "font-display text-3xl font-medium uppercase leading-none tracking-tight text-fg sm:text-4xl",
										children: "CCBF 2026"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1.5 max-w-xl text-sm text-muted",
										children: [BEERS.length, " øl · 17–22 · unlimited pours. Sorter, kryds af, giv score som på Untappd, og se hvad holdet har smagt."]
									})
								] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setCrewOpen((o) => !o),
								className: "flex h-11 shrink-0 items-center gap-2 rounded-md border border-border bg-elevated px-3 text-sm text-fg",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex size-7 items-center justify-center rounded-full bg-accent font-display text-xs text-accent-fg",
									children: active.name ? initials(active.name) : "DU"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden max-w-28 truncate sm:inline",
									children: active.name || "Dit navn"
								})]
							})]
						}),
						crewOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CrewPanel, {
							members,
							activeId,
							friendName,
							onFriendName: setFriendName,
							onSubmitFriend: submitFriend,
							onActive: setActive,
							onRename: rename,
							onRemove: removeMember
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-2 sm:max-w-md",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Smagt",
									value: `${tasted}/${BEERS.length}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Din snit",
									value: avg == null ? "–" : avg.toFixed(2)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "På listen",
									value: String(rows.length)
								})
							]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-6xl px-4 py-5 sm:px-6 sm:py-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "relative block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: query,
								onChange: (e) => setQuery(e.target.value),
								placeholder: "Søg øl, bryggeri, stil…",
								className: "pl-10"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2 overflow-x-auto pb-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
								active: family === "all",
								onClick: () => setFamily("all"),
								children: "Alle stile"
							}), FAMILIES.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
								active: family === f,
								onClick: () => setFamily(f),
								children: FAMILY_LABEL[f]
							}, f))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-2 sm:flex-row sm:items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: brewery,
								onChange: (e) => setBrewery(e.target.value),
								className: "h-11 rounded-md border border-border bg-elevated px-3 text-sm text-fg focus:border-accent/60 focus:outline-none focus:ring-2 focus:ring-accent/30 sm:max-w-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "all",
									children: "Alle bryggerier"
								}), BREWERIES.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: name,
									children: name
								}, name))]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-2 overflow-x-auto",
								children: [
									["all", "Alle øl"],
									["todo", "Ikke smagt"],
									["mine", "Mine"],
									["want", "Skal smages"],
									["friends", "Venner har smagt"]
								].map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
									active: drunkFilter === key,
									onClick: () => setDrunkFilter(key),
									children: label
								}, key))
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 overflow-hidden rounded-xl border border-border bg-surface",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "hidden md:block",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full text-left text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
									className: "border-b border-border bg-elevated/70 text-xs uppercase tracking-wider text-subtle",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Th, { className: "w-12" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortTh, {
											k: "name",
											current: sortKey,
											dir: sortDir,
											onClick: toggleSort,
											children: "Øl"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortTh, {
											k: "brewery",
											current: sortKey,
											dir: sortDir,
											onClick: toggleSort,
											children: "Bryggeri"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortTh, {
											k: "style",
											current: sortKey,
											dir: sortDir,
											onClick: toggleSort,
											children: "Stil"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortTh, {
											k: "abv",
											current: sortKey,
											dir: sortDir,
											onClick: toggleSort,
											children: "ABV"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortTh, {
											k: "untappd",
											current: sortKey,
											dir: sortDir,
											onClick: toggleSort,
											children: "Untappd"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortTh, {
											k: "mine",
											current: sortKey,
											dir: sortDir,
											onClick: toggleSort,
											children: "Min"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-3 font-medium",
											children: "Hold"
										})
									] })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((beer) => {
									const mine = checkinFor(activeId, beer.id);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										onClick: () => setSelectedId(beer.id),
										className: "cursor-pointer border-b border-border/70 last:border-0 hover:bg-elevated/50",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-2.5",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DrunkToggle, {
													drunk: mine.drunk,
													onToggle: () => setDrunk(beer.id, !mine.drunk)
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-2.5",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-2",
													children: [mine.want ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-3.5 fill-rating text-rating" }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-medium text-fg",
														children: beer.name
													})]
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
												className: "px-3 py-2.5 text-muted",
												children: [beer.brewery, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "ml-1 text-subtle",
													children: beer.countryCode
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-2.5 text-muted",
												children: beer.style
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-2.5 font-mono tabular-nums text-muted",
												children: formatAbv(beer.abv)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-2.5",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UntappdCell, { beer })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-2.5",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreBadge, { score: mine.score })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-2.5",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FriendPills, {
													beerId: beer.id,
													members,
													activeId,
													checkinFor
												})
											})
										]
									}, beer.id);
								}) })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "divide-y divide-border md:hidden",
							children: rows.map((beer) => {
								const mine = checkinFor(activeId, beer.id);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setSelectedId(beer.id),
									className: "flex w-full items-start gap-3 px-3 py-3.5 text-left",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DrunkToggle, {
										drunk: mine.drunk,
										onToggle: () => setDrunk(beer.id, !mine.drunk)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "min-w-0 flex-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-1.5",
												children: [mine.want ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-3.5 fill-rating text-rating" }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "truncate font-medium text-fg",
													children: beer.name
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "mt-0.5 block truncate text-xs text-muted",
												children: [
													beer.brewery,
													" · ",
													beer.style,
													" · ",
													formatAbv(beer.abv)
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "mt-2 flex items-center gap-3",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UntappdCell, { beer }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-xs text-subtle",
														children: "Min"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreBadge, { score: mine.score }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FriendPills, {
														beerId: beer.id,
														members,
														activeId,
														checkinFor
													})
												]
											})
										]
									})]
								}) }, beer.id);
							})
						}),
						rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "px-4 py-12 text-center text-sm text-muted",
							children: "Ingen øl matcher filtrene."
						}) : null
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Root, {
				open: selected != null,
				onOpenChange: (open) => {
					if (!open) setSelectedId(null);
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Drawer.Portal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Overlay, { className: "fixed inset-0 z-40 bg-bg/70" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Drawer.Content, {
					className: "fixed inset-x-0 bottom-0 z-50 mx-auto flex max-h-[92dvh] max-w-lg flex-col rounded-t-xl border border-border bg-surface outline-none",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mt-3 h-1 w-10 rounded-full bg-border" }), selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BeerDetail, {
						beer: selected,
						mine: checkinFor(activeId, selected.id),
						members,
						activeId,
						checkinFor,
						onDrunk: (v) => setDrunk(selected.id, v),
						onScore: (v) => setScore(selected.id, v),
						onWant: (v) => setWant(selected.id, v),
						onClose: () => setSelectedId(null)
					}) : null]
				})] })
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-border bg-surface px-3 py-2.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] font-medium uppercase tracking-wider text-subtle",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-xl font-medium tabular-nums text-fg",
			children: value
		})]
	});
}
function Chip({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("h-9 shrink-0 rounded-full border px-3 text-sm transition-colors duration-150", active ? "border-accent bg-accent text-accent-fg" : "border-border bg-elevated text-muted hover:text-fg"),
		children
	});
}
function Th({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
		className: cn("px-3 py-3 font-medium", className),
		children
	});
}
function SortTh({ k, current, dir, onClick, children }) {
	const active = current === k;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
		className: "px-3 py-3",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: (e) => {
				e.stopPropagation();
				onClick(k);
			},
			className: cn("inline-flex items-center gap-1 font-medium", active ? "text-fg" : "text-subtle hover:text-fg"),
			children: [children, active ? dir === "desc" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-3.5" }) : null]
		})
	});
}
function DrunkToggle({ drunk, onToggle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		role: "checkbox",
		"aria-checked": drunk,
		"aria-label": drunk ? "Smagt" : "Ikke smagt",
		tabIndex: 0,
		onClick: (e) => {
			e.stopPropagation();
			onToggle();
		},
		onKeyDown: (e) => {
			if (e.key === " " || e.key === "Enter") {
				e.preventDefault();
				e.stopPropagation();
				onToggle();
			}
		},
		className: cn("inline-flex size-8 items-center justify-center rounded-sm border transition-colors duration-150", drunk ? "border-accent bg-accent text-accent-fg" : "border-border bg-elevated text-transparent hover:border-accent/50"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
			className: "size-4",
			strokeWidth: 3
		})
	});
}
function UntappdCell({ beer }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
		href: beer.untappdUrl,
		target: "_blank",
		rel: "noreferrer",
		onClick: (e) => e.stopPropagation(),
		className: "inline-flex items-center gap-1 font-mono text-sm tabular-nums text-rating hover:underline",
		children: [formatRating(beer.untappdRating), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3 opacity-70" })]
	});
}
function FriendPills({ beerId, members, activeId, checkinFor }) {
	const friends = members.filter((m) => m.id !== activeId && checkinFor(m.id, beerId).drunk);
	if (friends.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-xs text-subtle",
		children: "–"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "flex flex-wrap gap-1",
		children: friends.map((m) => {
			const c = checkinFor(m.id, beerId);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				title: `${m.name || "Ven"} ${c.score ?? ""}`,
				className: "inline-flex items-center gap-1 rounded-full bg-elevated px-1.5 py-0.5 font-mono text-[11px] tabular-nums text-muted",
				children: [initials(m.name || "Ven"), c.score != null ? ` ${c.score.toFixed(1)}` : ""]
			}, m.id);
		})
	});
}
function CrewPanel({ members, activeId, friendName, onFriendName, onSubmitFriend, onActive, onRename, onRemove }) {
	const active = members.find((m) => m.id === activeId) ?? members[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-wider text-subtle",
				children: "Holdet"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-3 block text-sm text-muted",
				children: ["Dit navn", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "mt-1.5",
					value: active.name,
					placeholder: "Skriv dit navn",
					onChange: (e) => onRename(active.id, e.target.value)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: members.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onActive(m.id),
					className: cn("inline-flex h-9 items-center gap-2 rounded-full border px-3 text-sm", m.id === activeId ? "border-accent bg-accent text-accent-fg" : "border-border bg-elevated text-muted"),
					children: [m.name || (m.id === members[0].id ? "Dig" : "Ven"), m.id !== members[0].id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						role: "button",
						tabIndex: 0,
						"aria-label": "Fjern",
						onClick: (e) => {
							e.stopPropagation();
							onRemove(m.id);
						},
						onKeyDown: (e) => {
							if (e.key === "Enter") onRemove(m.id);
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
					}) : null]
				}, m.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-3 flex gap-2",
				onSubmit: (e) => {
					e.preventDefault();
					onSubmitFriend();
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: friendName,
					onChange: (e) => onFriendName(e.target.value),
					placeholder: "Tilføj ven"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					size: "icon",
					"aria-label": "Tilføj ven",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs text-subtle",
				children: "Skift aktiv person for at tjekke ind og score på deres vegne — nemt ved bordet i hallen."
			})
		]
	});
}
function BeerDetail({ beer, mine, members, activeId, checkinFor, onDrunk, onScore, onWant, onClose }) {
	const friends = members.filter((m) => m.id !== activeId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overflow-y-auto px-5 pt-3 pb-[max(1.5rem,env(safe-area-inset-bottom))]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Title, {
					className: "font-display text-2xl font-medium uppercase tracking-tight text-fg",
					children: beer.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Drawer.Description, {
					className: "mt-1 text-sm text-muted",
					children: [
						beer.brewery,
						" · ",
						beer.country,
						" · ",
						beer.style
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					className: "flex size-10 items-center justify-center rounded-md text-muted hover:text-fg",
					"aria-label": "Luk",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
						label: "ABV",
						value: formatAbv(beer.abv)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
						label: "IBU",
						value: beer.ibu == null ? "–" : String(beer.ibu)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
						label: "Untappd",
						value: beer.untappdRating == null ? "–" : `${formatRating(beer.untappdRating)}${beer.untappdCount ? ` (${beer.untappdCount})` : ""}`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: mine.drunk ? "primary" : "secondary",
						className: "flex-1",
						onClick: () => onDrunk(!mine.drunk),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), mine.drunk ? "Smagt" : "Kryds af"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: mine.want ? "primary" : "secondary",
						size: "icon",
						"aria-label": "Skal smages",
						onClick: () => onWant(!mine.want),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: cn("size-4", mine.want && "fill-current") })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: beer.untappdUrl,
						target: "_blank",
						rel: "noreferrer",
						className: "inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-md border border-border bg-elevated px-4 text-sm font-medium text-fg",
						children: ["Untappd", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-4" })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreControl, {
					value: mine.score,
					onChange: onScore
				})
			}),
			friends.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-wider text-subtle",
					children: "Holdet"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 divide-y divide-border",
					children: friends.map((m) => {
						const c = checkinFor(m.id, beer.id);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between py-2.5 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-fg",
								children: m.name || "Ven"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono tabular-nums text-muted",
								children: c.drunk ? c.score != null ? c.score.toFixed(2) : "Smagt" : "Ikke smagt"
							})]
						}, m.id);
					})
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-sm text-subtle",
				children: "Tilføj venner under holdet for at se deres scores ved siden af dine."
			})
		]
	});
}
function Meta({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-border bg-elevated px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] uppercase tracking-wider text-subtle",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-sm tabular-nums text-fg",
			children: value
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FestivalApp, {});
}
//#endregion
export { Home as component };
